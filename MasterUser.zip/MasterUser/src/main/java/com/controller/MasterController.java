package com.controller;

import java.util.HashMap;   
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.beans.Master;
import com.exception.ResourceNotFoundException;
import com.repository.MasterRepository;

import jakarta.websocket.server.PathParam;

@RestController
@RequestMapping("/api/v1/")
public class MasterController {

	@Autowired
	private MasterRepository masterRepository;

	@GetMapping("/masters")
	public List<Master> getAllUsers() {
		return masterRepository.findAll();
	}

	@GetMapping("/masters/{id}")
	public ResponseEntity<Master> getUserById(@PathVariable(value = "id") Long userId)
			throws ResourceNotFoundException {
		Master mt = masterRepository.findById(userId)
				.orElseThrow(() -> new ResourceNotFoundException("Master not found for this id :: " + userId));
		return ResponseEntity.ok().body(mt);
	}

	@GetMapping("/masters")
	public ResponseEntity<Master> getUsersByIdD(@PathParam(value = "id") Long userId)
			throws ResourceNotFoundException {
		Master mt = masterRepository.findById(userId)
				.orElseThrow(() -> new ResourceNotFoundException("Master not found for this id :: " + userId));
		return ResponseEntity.ok().body(mt);
	}

	@PostMapping("/add")
	public Master createUser(@Validated @RequestBody Master master) {
		return masterRepository.save(master);
	}

	@PutMapping("/masters/{id}")
	public ResponseEntity<Master> updateUser(@Validated @PathVariable(value = "id")Long userId,
	 @RequestBody Master masterDetails)throws ResourceNotFoundException {
		Master user= masterRepository.findById(userId)
				.orElseThrow(() -> new ResourceNotFoundException("Master not found for this id :: " + userId));
		user.setName(masterDetails.getName());
		user.setAge(masterDetails.getAge());
		user.setAadhar(masterDetails.getAadhar());
		user.setPan(masterDetails.getPan());
		user.setAddress(masterDetails.getAddress());
        final Master updateUser = masterRepository.save(user);	
		return ResponseEntity.ok().body(updateUser);
	}

	@DeleteMapping("/masters/{id}")
		public Map<String, Boolean> deleteEmployee(@PathVariable(value = "id")Long userId)
		 throws ResourceNotFoundException {
			Master mt= masterRepository.findById(userId)
					.orElseThrow(() -> new ResourceNotFoundException("Master not found for this id :: " + userId));
			masterRepository.delete(mt);
 		Map<String, Boolean> response = new HashMap<>();
 		response.put("deleted", Boolean.TRUE);
 		return response;
 	}
}