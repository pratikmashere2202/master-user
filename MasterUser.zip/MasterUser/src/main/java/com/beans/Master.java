package com.beans;

import jakarta.persistence.Column;  
import jakarta.persistence.Table;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
@Table(name = "masterinfo")

public class Master {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@Column(name = "name", nullable = false)
	private String name;
	@Column(name = "age", nullable = false)
	private int age;
	@Column(name = "aadhar", nullable = false)
	private int aadhar;
	@Column(name = "pan", nullable = false)
	private String pan;
	@Column(name = "address", nullable = false)
	private String address;

	public Master() {

	}

	public Master(int id, String name, int age, int aadhar, String pan, String address) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.aadhar = aadhar;
		this.pan = pan;
		this.address = address;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getAadhar() {
		return aadhar;
	}

	public void setAadhar(int aadhar) {
		this.aadhar = aadhar;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Master [id=" + id + ", name=" + name + ", age=" + age + ", aadhar=" + aadhar + ", pan=" + pan
				+ ", address=" + address + "]";
	}
}