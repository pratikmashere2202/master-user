import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MasterListComponent } from './master-list/master-list.component';
import { CreateMasterComponent } from './create-master/create-master.component';
import { FormsModule } from '@angular/forms';
import { UpdateMasterComponent } from './update-master/update-master.component';
import { MasterDetailsComponent } from './master-details/master-details.component';


@NgModule({
  declarations: [
    AppComponent,
    MasterListComponent,
    CreateMasterComponent,
    UpdateMasterComponent,
    MasterDetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
