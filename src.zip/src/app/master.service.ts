import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable} from 'rxjs';
import { Master } from './master';
@Injectable({
  providedIn: 'root'
})
export class MasterService {
  private baseURL = "http://localhost:9191/api/v1/masters";
  constructor(private httpClient: HttpClient) { }

  getMasterList() :Observable<Master[]>{
    return this.httpClient.get<Master[]>('${this.baseURL}');
  }
  createMaster(master:Master):Observable<Object>{
    return this.httpClient.post('${this.baseURL}',master);
  }

  getMasterById(id:number):Observable<Master>{
    return this.httpClient.get<Master>('${this.baseURL}/${id}');
  }

  updateMaster(id:number, master:Master):Observable<Object>{
    return this.httpClient.put('${this.baseURL}/${id}',master);
  }

  deleteMaster(id:number):Observable<Object>{
    return this.httpClient.delete('${this.baseURL}/${id}');
  }
}