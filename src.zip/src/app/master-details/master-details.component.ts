import { Component ,OnInit} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Master } from '../master';
import { MasterService } from '../master.service';

@Component({
  selector: 'app-master-details',
  templateUrl: './master-details.component.html',
  styleUrls: ['./master-details.component.sass']
})
export class MasterDetailsComponent implements OnInit{
  id:number;
  master:Master
  constructor(private route:ActivatedRoute, private masterService:MasterService){}
  ngOnInit():void{
    this.id= this.route.snapshot.params['id'];
    this.master=new Master();
    this.masterService.getMasterById(this.id).subscribe(data=>{
      this.master=data;
    })
  }
}