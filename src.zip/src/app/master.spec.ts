import { Master } from './master';

describe('Master', () => {
  it('should create an instance', () => {
    expect(new Master()).toBeTruthy();
  });
});
