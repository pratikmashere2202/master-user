export class Master {
    id: number;
    name: string;
    age: number;
    aadhar: number;
    pan: string;
    address: string;
}
