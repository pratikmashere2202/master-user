import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Master } from '../master';
import { MasterService } from '../master.service';

@Component({
  selector: 'app-create-master',
  templateUrl: './create-master.component.html',
  styleUrls: ['./create-master.component.sass']
})
export class CreateMasterComponent implements OnInit{
  master:Master=new Master();
  constructor(private masterService:MasterService,
    private router:Router){};

  ngOnInit(): void {   
  }

  saveMaster(){
    this.masterService.createMaster(this.master).subscribe(data =>{
    console.log(data);
    this.goToMasterList();
    },
    error=>console.log(error));
  }
  goToMasterList(){
    this.router.navigate(['/masters']);
  }
  onSubmit(){
    console.log(this.master);
    this.saveMaster();
  }
}