import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateMasterComponent } from './create-master/create-master.component';
import { MasterDetailsComponent } from './master-details/master-details.component';
import { MasterListComponent } from './master-list/master-list.component';
import { UpdateMasterComponent } from './update-master/update-master.component';

const routes: Routes = [
  {path: 'masters', component: MasterListComponent},
  {path: 'create-master', component:CreateMasterComponent},
  {path:'', redirectTo:'masters',pathMatch:'full'},
  {path:'update-master/:id', component:UpdateMasterComponent},
  {path:'master-details/:id',component:MasterDetailsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
