import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Master } from '../master';
import { MasterService } from '../master.service';

@Component({
  selector: 'app-master-list',
  templateUrl: './master-list.component.html',
  styleUrls: ['./master-list.component.sass']
})
export class MasterListComponent implements OnInit{

  masters : Master[];
constructor(private masterService:MasterService, 
  private router:Router){}
ngOnInit(): void {
  this.getMasters();
}
private getMasters(){
  this.masterService.getMasterList().subscribe(data =>{
     this.masters =data;
  });
}
masterDetails(id:number){
  this.router.navigate(['master-details',id]);
}
updateMaster(id:number){
   this.router.navigate(['update-master',id]);
}

deleteMaster(id:number){
  this.masterService.deleteMaster(id).subscribe(data=>{
    console.log(data);
    this.getMasters();
  })
}
}