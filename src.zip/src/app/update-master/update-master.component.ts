import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Master } from '../master';
import { MasterService } from '../master.service';

@Component({
  selector: 'app-update-master',
  templateUrl: './update-master.component.html',
  styleUrls: ['./update-master.component.sass']
})
export class UpdateMasterComponent implements OnInit{
  id:number;
  master:Master=new Master();
  constructor(private masterService:MasterService,
    private route:ActivatedRoute,
    private router:Router){}

  ngOnInit(): void {
    this.id=this.route.snapshot.params['id'];
    this.masterService.getMasterById(this.id).subscribe(data=>{
      this.master=data;
    }, error=>console.log(error)); 
  }  

  onSubmit(){
    this.masterService.updateMaster(this.id, this.master).subscribe(data=>{
    this.goToMasterList();
    }, error=>console.log(error));
  }
  goToMasterList(){
    this.router.navigate(['/masters']);
  }
}